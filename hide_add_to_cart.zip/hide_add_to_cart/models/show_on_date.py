import json
import logging
from datetime import datetime
from datetime import date

from odoo import api, fields, models, _
from odoo.addons.base.models.res_partner import WARNING_MESSAGE, WARNING_HELP
from odoo.exceptions import ValidationError
from odoo.tools.float_utils import float_round

_logger = logging.getLogger(__name__)


class CustomProductTemplate(models.Model):
    _inherit = 'product.template'


    launch_date = fields.Date(default=datetime.today(), string='Launch Date', required=True)

    def _is_add_to_cart_possible(self, parent_combination=None):
        """
        It's possible to add to cart (potentially after configuration) if
        there is at least one possible combination.

        :param parent_combination: the combination from which `self` is an
            optional or accessory product.
        :type parent_combination: recordset `product.template.attribute.value`

        :return: True if it's possible to add to cart, else False
        :rtype: bool
        """
        self.ensure_one()

        if not self.active:
            # for performance: avoid calling `_get_possible_combinations`
            return False
        if self.launch_date > date.today():
            print('=======PRODUCT FOUND')
            # if Date.
            return False
        # product = request.env['product.template'].browse(int('45'))
        return next(self._get_possible_combinations(parent_combination), False) is not False
