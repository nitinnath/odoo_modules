//odoo.hide_add_to_cart = function(instance) {
//
//  instance.web.FormView = instance.web.FormView.extend({
//      function(ev) {
//          ev.preventDefault();
//          ev.stopPropagation();
//
//          var field_values = this.get_fields_values();
//          var ids = this.get_selected_ids();
//          var id = field_values['id']
//          var model = this.model
//alert('workingg');
//          openerp.jsonRpc('/custom_addons/hide_add_to_cart/', 'call', { model: model, ids: ids, id: id} ).then(function (data) {
//           alert('workingg');
//          });
//
//      },
//  });
//
//}