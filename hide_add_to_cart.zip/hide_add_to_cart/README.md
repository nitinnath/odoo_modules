# website_sale_hide_add_to_cart
Hide Add to Cart in Product

# Before
<img src="static/description/ss_00.png">

# After
<img src="static/description/ss_01.png">
