# -*- coding: utf-8 -*-

{
    'name': '"Add To Cart" hide on product',
    'version': '1.0',
    'category': 'Website',
    'summary': 'Custom website product sales',
    'author': 'Nitin Nath Giri',
    'email': 'nitinnath.oms@gmail.com',
    'depends': ['web','website','sale'],
    'data': [
        'views/template_product.xml',
        'views/web_template.xml',
    ],
    'installable': True,
    'auto_install': False
}